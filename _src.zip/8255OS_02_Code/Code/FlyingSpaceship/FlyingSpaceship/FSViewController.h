//
//  FSViewController.h
//  FlyingSpaceship
//

//  Copyright (c) 2014 RahulBorawar. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface FSViewController : UIViewController

@end
