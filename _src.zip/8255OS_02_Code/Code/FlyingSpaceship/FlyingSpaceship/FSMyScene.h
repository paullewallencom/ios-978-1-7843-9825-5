//
//  FSMyScene.h
//  FlyingSpaceship
//

//  Copyright (c) 2014 RahulBorawar. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface FSMyScene : SKScene

@end
