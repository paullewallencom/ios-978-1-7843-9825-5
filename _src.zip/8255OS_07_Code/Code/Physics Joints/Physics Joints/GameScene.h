//
//  GameScene.h
//  Physics Joints
//

//  Copyright (c) 2014 mb. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene <SKPhysicsContactDelegate>

@end
