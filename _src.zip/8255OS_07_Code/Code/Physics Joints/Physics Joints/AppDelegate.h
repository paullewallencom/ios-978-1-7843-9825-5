//
//  AppDelegate.h
//  Physics Joints
//
//  Created by Bhanu Birani on 18/11/14.
//  Copyright (c) 2014 mb. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

