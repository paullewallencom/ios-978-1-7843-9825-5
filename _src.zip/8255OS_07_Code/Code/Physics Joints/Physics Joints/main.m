//
//  main.m
//  Physics Joints
//
//  Created by Bhanu Birani on 18/11/14.
//  Copyright (c) 2014 mb. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
