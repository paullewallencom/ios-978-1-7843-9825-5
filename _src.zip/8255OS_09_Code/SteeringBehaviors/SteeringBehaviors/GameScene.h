//
//  GameScene.h
//  SteeringBehaviors
//

//  Copyright (c) 2014 mb. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GameScene : SKScene

@end
