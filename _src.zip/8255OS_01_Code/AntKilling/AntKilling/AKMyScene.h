//
//  AKMyScene.h
//  AntKilling
//

//  Copyright (c) 2014 YourCompanyName. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface AKMyScene : SKScene

@end
