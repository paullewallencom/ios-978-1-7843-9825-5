//
//  AKViewController.h
//  AntKilling
//

//  Copyright (c) 2014 YourCompanyName. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>

@interface AKViewController : UIViewController

@end
