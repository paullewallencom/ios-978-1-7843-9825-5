//
//  AKAppDelegate.h
//  AntKilling
//
//  Created by Bhanu Birani on 21/07/14.
//  Copyright (c) 2014 YourCompanyName. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AKAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
