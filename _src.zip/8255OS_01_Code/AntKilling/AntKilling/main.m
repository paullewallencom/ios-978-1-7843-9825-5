//
//  main.m
//  AntKilling
//
//  Created by Bhanu Birani on 21/07/14.
//  Copyright (c) 2014 YourCompanyName. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AKAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AKAppDelegate class]));
    }
}
